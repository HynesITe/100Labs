﻿[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$dir = "c:\Source"
$FileURI = "https://github.com/HynesITe/100Labs/raw/master/DP010-UseDsc/iometer.zip"
New-Item $dir -ItemType directory
$output = "$dir\iometer.zip"
(New-Object System.Net.WebClient).DownloadFile($FileURI,$output)
$disks = Get-PhysicalDisk –CanPool $true
New-StoragePool -FriendlyName "DataPool" -StorageSubsystemFriendlyName "Windows Storage*" -PhysicalDisks $disks | New-VirtualDisk -FriendlyName "DataDisk" -UseMaximumSize -NumberOfColumns $disks.Count -ResiliencySettingName "Simple" -ProvisioningType Fixed -Interleave 65536 | Initialize-Disk -Confirm:$False -PassThru | New-Partition -DriveLetter H –UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "DATA" -Confirm:$false			
		    